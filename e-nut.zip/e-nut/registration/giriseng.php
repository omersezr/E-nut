<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
    <li><a>USER</a>
       <ul>
            <li><a href="carteng.php">My Cart</a></li>
			<li><a href="anasayfaeng.php">Log Out</a></li>
       </ul>
<li><a>LANGUAGE</a>
			<ul>
			<li><a href="giris.php">Türkçe</a></li>	
		    <li><a href="giriseng.php">English</a></li>  
	   </ul>
	<li><a href="contactgiriseng.php">CONTACT US</a></li>
	<li><a href="aboutgiriseng.php">ABOUT US</a></li>	
	<li><a>OUR PRODUCTS</a>
		<ul>
			<li><a href="findikeng.php">NUT</a></li>
			<li><a href="fistikeng.php">PEANUT</a></li>
			<li><a href="cevizeng.php">WALNUT</a></li>
			<li><a href="bademeng.php">ALMOND</a></li>
		</ul>
		</ul>
		</ul>
</ul>
<a href="giriseng.php">
  <img src="logo.png"  width="120" height="125" />
</a>
</html>