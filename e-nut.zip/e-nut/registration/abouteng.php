<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a href="registereng.php">LOG IN/REGISTER</a></li>
	<li><a>LANGUAGE</a>
			<ul>
		    <li><a href="about.php">Türkçe</a></li>
	        <li><a href="abouteng.php">English</a></li>
        </ul>	
	<li><a href="contacteng.php">CONTACT US</a></li>	
	<li><a href="abouteng.php">ABOUT US</a></li>
	<li><a>OUR PRODUCTS</a>
		<ul>
			<li><a>NUT</a></li>
			<li><a>PEANUT</a></li>
			<li><a>WALNUT</a></li>
			<li><a>ALMOND</a></li>
		</ul>		
</ul>
<a href="anasayfaeng.php">
  <img src="logo.png" width="120" height="125" />
</a>
<head>
<style>
.text{
  position: absolute;
  top: 150px;
  left: 260px;
  font-size: 18px;
}
.text2 {
  position: absolute;
  top: 220px;
  left: 250px;
  font-size: 20px;
}
.text3 {
  position: absolute;
  top: 475px;
  left: 900px;
  font-size: 18px;
}
.text4 {
  position: absolute;
  top: 550px;
  left: 900px;
  font-size: 25px;
}

</style>
</head>
<body>

   <div class="text"><h1>About Us<h1></div>
   <div class="text2">We are a small comapny aiming to bring fresh dried nuts to all customers.
   <br>All of our products are from domestic manufacturers.
   <br>Customer satisfaction is our most important value.</div>
   <div class="text3"><h1>Founders<h1></div>
   <div class="text4">İlhan Can Güven &ensp; Furkan Ayşavkı<br>Doğancan Aydın &ensp; Ömer Sezer</div>


</body>
</html>