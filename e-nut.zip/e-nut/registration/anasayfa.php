<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a href="register.php">GİRİŞ YAP/ÜYE OL</a></li>
	<li><a>DİL</a>
			<ul>
			<li><a href="anasayfa.php">Türkçe</a></li>	
		    <li><a href="anasayfaeng.php">English</a></li>  
	   </ul>
	<li><a href="contact.php">İLETİŞİM</a></li>
	<li><a href="about.php">HAKKIMIZDA</a></li>	
	<li><a>ÜRÜNLERİMİZ</a>
		<ul>
			<li><a>Fındık</a></li>	
			<li><a>Fıstık</a></li>
			<li><a>Ceviz</a></li>
			<li><a>Badem</a></li>
		</ul>
</ul>
<a href="anasayfa.php">
  <img src="logo.png" width="120" height="125" />
</a>
</html>