<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a href="register.php">GİRİŞ YAP/ÜYE OL</a></li>
	<li><a>DİL</a>
			<ul>
			<li><a href="about.php">Türkçe</a></li>	
		    <li><a href="abouteng.php">English</a></li>  			
        </ul>
	<li><a href="contact.php">İLETİŞİM</a></li>
	<li><a href="about.php">HAKKIMIZDA</a></li>
	<li><a>ÜRÜNLERİMİZ</a>
		<ul>
			<li><a>Fındık</a></li>
			<li><a>Fıstık</a></li>
			<li><a>Ceviz</a></li>
			<li><a>Badem</a></li>
		</ul>		
</ul>
<a href="anasayfa.php">
  <img src="logo.png" width="120" height="125" />
</a>	
<head>
<style>
.text{
  position: absolute;
  top: 150px;
  left: 260px;
  font-size: 18px;
}
.text2 {
  position: absolute;
  top: 220px;
  left: 250px;
  font-size: 20px;
}
.text3 {
  position: absolute;
  top: 475px;
  left: 900px;
  font-size: 18px;
}
.text4 {
  position: absolute;
  top: 550px;
  left: 900px;
  font-size: 25px;
}

</style>
</head>
<body>

   <div class="text"><h1>Hakkımızda<h1></div>
   <div class="text2">Tüm müşterilerine taze kuruyemiş ulaştırmayı hedefleyen küçük bir şirketiz. 
   <br>Ürünlerimizin hepsi yerli üreticilerimizden gelmektedir.
   <br>Müşteri memnuniyeti en önemli değerimizdir.</div>
   <div class="text3"><h1>Kurucular<h1></div>
   <div class="text4">İlhan Can Güven &ensp; Furkan Ayşavkı<br>Doğancan Aydın &ensp; Ömer Sezer</div>


</body>
</html>