<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
    <li><a>USER</a>
       <ul>
            <li><a href="carteng.php">My Cart</a></li>
			<li><a href="anasayfaeng.php">Log Out</a></li>
       </ul>
<li><a>LANGUAGE</a>
			<ul>
			<li><a href="contactgiris.php">Türkçe</a></li>	
		    <li><a href="contactgiriseng.php">English</a></li>  
	   </ul>
	<li><a href="contactgiriseng.php">CONTACT US</a></li>
	<li><a href="aboutgiriseng.php">ABOUT US</a></li>	
	<li><a>OUR PRODUCTS</a>
		<ul>
			<li><a href="findikeng.php">NUT</a></li>
			<li><a href="fistikeng.php">PEANUT</a></li>
			<li><a href="cevizeng.php">WALNUT</a></li>
			<li><a href="bademeng.php">ALMOND</a></li>
		</ul>
		</ul>
		</ul>
</ul>
<a href="giriseng.php">
  <img src="logo.png"  width="120" height="125" />
</a>
<head>
<style>
.text{
  position: absolute;
  top: 150px;
  left: 250px;
  font-size: 18px;
}
.text2 {
  position: absolute;
  top: 220px;
  left: 250px;
  font-size: 20px;
}
.text3 {
  position: absolute;
  top: 300px;
  left: 250px;
  font-size: 25px;
}
.text4 {
  position: absolute;
  top: 0px;
  left: 300px;
  font-size: 25px;
}
.text5 {
  position: absolute;
  top: 200px;
  left: 200px;
  font-size: 18px;
}
.text6 {
  position: absolute;
  top: 50px;
  left: -80px;
  font-size: 25px;
}
.nowrap {
  white-space: nowrap ;
}
</style>
</head>
<body>

   <div class="text"><h1>Contact Us<h1></div>
   <div class="text2">You can contact us 24/7 via provided contact options.</div>
   <div class="text3">E-Mail:<a href="mailto:info@enut.com?Subject=E-NUT" target="_top">info@enut.com</a>
   <div class="text4">Phone:<a href="tel:5357575663">+90(535)7575663</a>
   <div class="text5"><h1>Address:<h1/></a>
   <div class="text6"><span class="nowrap"><a href="https://www.google.com/maps/@41.0673836,28.9464376,17z?hl=en"target="_blank">Istanbul Bilgi University, Emniyettepe District, Kazım Karabekir St.<br>No:13 D:2, 34060 Eyüp/İstanbul</a></span></a>
</div>
</body>
</html>