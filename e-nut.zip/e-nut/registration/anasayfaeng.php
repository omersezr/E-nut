<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a href="registereng.php">LOG IN/REGISTER</a></li> 
    <li><a>LANGUAGE</a>
			<ul>
		    <li><a href="anasayfa.php">Türkçe</a></li>
			<li><a href="anasayfaeng.php">English</a></li>
       </ul>		
	<li><a href="contacteng.php">CONTACT US</a></li>
	<li><a href="abouteng.php">ABOUT US</a></li>	
	<li><a>OUR PRODUCTS</a>
		<ul>
			<li><a>NUT</a></li>
			<li><a>PEANUT</a></li>
			<li><a>WALNUT</a></li>
			<li><a>ALMOND</a></li>
		</ul>	
</ul>
<a href="anasayfaeng.php">
  <img src="logo.png" width="120" height="125" />
</a>
</html>