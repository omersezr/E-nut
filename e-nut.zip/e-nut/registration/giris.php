<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a>KULLANICI</a>
       <ul>
            <li><a href="cart.php">Sepetim</a></li>
			<li><a href="anasayfa.php">Çıkış Yap</a></li>
       </ul>
<li><a>DİL</a>
			<ul>
			<li><a href="giris.php">Türkçe</a></li>	
		    <li><a href="giriseng.php">English</a></li>  
	   </ul>
	<li><a href="contactgiris.php">İLETİŞİM</a></li>
	<li><a href="aboutgiris.php">HAKKIMIZDA</a></li>	
	<li><a>ÜRÜNLERİMİZ</a>
		<ul>
			<li><a href="findik.php">Fındık</a></li>
			<li><a href="fistik.php">Fıstık</a></li>
			<li><a href="ceviz.php">Ceviz</a></li>
			<li><a href="badem.php">Badem</a></li>
		</ul>
		</ul>
		</ul>
</ul>
<a href="giris.php">
  <img src="logo.png"  width="120" height="125" />
</a>
</html>