<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
    <li><a>USER</a>
       <ul>
            <li><a href="carteng.php">My Cart</a></li>
			<li><a href="anasayfaeng.php">Log Out</a></li>
       </ul>
<li><a>LANGUAGE</a>
			<ul>
			<li><a href="aboutgiris.php">Türkçe</a></li>	
		    <li><a href="aboutgiriseng.php">English</a></li>  
	   </ul>
	<li><a href="contactgiriseng.php">CONTACT US</a></li>
	<li><a href="aboutgiriseng.php">ABOUT US</a></li>	
	<li><a>OUR PRODUCTS</a>
		<ul>
			<li><a href="findikeng.php">NUT</a></li>
			<li><a href="fistikeng.php">PEANUT</a></li>
			<li><a href="cevizeng.php">WALNUT</a></li>
			<li><a href="bademeng.php">ALMOND</a></li>
		</ul>
		</ul>
		</ul>
</ul>
<a href="giriseng.php">
  <img src="logo.png" width="120" height="125" />
</a>	
<head>
<style>
.text{
  position: absolute;
  top: 150px;
  left: 260px;
  font-size: 18px;
}
.text2 {
  position: absolute;
  top: 220px;
  left: 250px;
  font-size: 20px;
}
.text3 {
  position: absolute;
  top: 475px;
  left: 900px;
  font-size: 18px;
}
.text4 {
  position: absolute;
  top: 550px;
  left: 900px;
  font-size: 25px;
}

</style>
</head>
<body>

   <div class="text"><h1>Hakkımızda<h1></div>
   <div class="text2">Tüm müşterilerine taze kuruyemiş ulaştırmayı hedefleyen küçük bir şirketiz. 
   <br>Ürünlerimizin hepsi yerli üreticilerimizden gelmektedir.
   <br>Müşteri memnuniyeti en önemli değerimizdir.</div>
   <div class="text3"><h1>Kurucular<h1></div>
   <div class="text4">İlhan Can Güven &ensp; Furkan Ayşavkı<br>Doğancan Aydın &ensp; Ömer Sezer</div>


</body>
</html>