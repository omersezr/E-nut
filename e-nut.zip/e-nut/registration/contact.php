<html>
<link href='style.css' rel='stylesheet'>
<ul>
	</li>
	<li><a href="register.php">GİRİŞ YAP/ÜYE OL</a></li>
	<li><a>DİL</a>
			<ul>
		    <li><a href="contact.php">Türkçe</a></li>	
		    <li><a href="contacteng.php">English</a></li>
        </ul>
	<li><a href="contact.php">İLETİŞİM</a></li>
	<li><a href="about.php">HAKKIMIZDA</a></li>
	<li><a>ÜRÜNLERİMİZ</a>
		<ul>
			<li><a>Fındık</a></li>
			<li><a>Fıstık</a></li>
			<li><a>Ceviz</a></li>
			<li><a>Badem</a></li>
		</ul>		
</ul>
<a href="anasayfa.php">
  <img src="logo.png" width="120" height="125" />
</a>
<head>
<style>
.text{
  position: absolute;
  top: 150px;
  left: 250px;
  font-size: 18px;
}
.text2 {
  position: absolute;
  top: 220px;
  left: 250px;
  font-size: 20px;
}
.text3 {
  position: absolute;
  top: 300px;
  left: 250px;
  font-size: 25px;
}
.text4 {
  position: absolute;
  top: 0px;
  left: 300px;
  font-size: 25px;
}
.text5 {
  position: absolute;
  top: 200px;
  left: 200px;
  font-size: 18px;
}
.text6 {
  position: absolute;
  top: 50px;
  left: -80px;
  font-size: 25px;
}
.nowrap {
  white-space: nowrap ;
}
</style>
</head>
<body>

   <div class="text"><h1>Bizimle İletişime Geçin:<h1></div>
   <div class="text2">Sağladığımız iletişim seçeneklerini kullanarak bizimle 7/24 iletişime geçebilirsiniz.</div>
   <div class="text3">E-Posta:<a href="mailto:info@enut.com?Subject=E-NUT" target="_top">info@enut.com</a>
   <div class="text4">Telefon:<a href="tel:5357575663">+90(535)7575663</a>
   <div class="text5"><h1>Adres:<h1/></a>
   <div class="text6"><span class="nowrap"><a href="https://www.google.com/maps/@41.0673836,28.9464376,17z?hl=tr"target="_blank">İstanbul Bilgi Üniversitesi, Emniyettepe Mahallesi, Kazım Karabekir Cd.<br>No:13 D:2, 34060 Eyüp/İstanbul</a></span></a>
</div>
</body>
</html>